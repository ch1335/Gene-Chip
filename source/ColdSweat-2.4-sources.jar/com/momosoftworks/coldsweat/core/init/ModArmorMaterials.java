package com.momosoftworks.coldsweat.core.init;

import com.momosoftworks.coldsweat.ColdSweat;
import com.momosoftworks.coldsweat.data.tag.ModItemTags;
import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.List;

public class ModArmorMaterials
{
    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS = DeferredRegister.create(Registries.ARMOR_MATERIAL, ColdSweat.MOD_ID);

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> HOGLIN = ARMOR_MATERIALS.register("hoglin", () -> new ArmorMaterial(
            Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.HELMET, 3);
                map.put(ArmorItem.Type.CHESTPLATE, 6);
                map.put(ArmorItem.Type.LEGGINGS, 5);
                map.put(ArmorItem.Type.BOOTS, 2);
            }), 25, SoundEvents.ARMOR_EQUIP_LEATHER, () -> Ingredient.of(ModItemTags.HOGLIN_LEATHERS),
            List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(ColdSweat.MOD_ID, "hoglin"))),
            1.5F, 0.0F));

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> GOAT_FUR = ARMOR_MATERIALS.register("goat_fur", () -> new ArmorMaterial(
            Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.HELMET, 2);
                map.put(ArmorItem.Type.CHESTPLATE, 5);
                map.put(ArmorItem.Type.LEGGINGS, 4);
                map.put(ArmorItem.Type.BOOTS, 1);
            }), 15, SoundEvents.ARMOR_EQUIP_LEATHER, () -> Ingredient.of(ModItemTags.GOAT_FURS),
            List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(ColdSweat.MOD_ID, "goat_fur"))),
            0.0F, 0.0F));

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> CHAMELEON = ARMOR_MATERIALS.register("chameleon", () -> new ArmorMaterial(
            Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                map.put(ArmorItem.Type.HELMET, 2);
                map.put(ArmorItem.Type.CHESTPLATE, 6);
                map.put(ArmorItem.Type.LEGGINGS, 5);
                map.put(ArmorItem.Type.BOOTS, 2);
            }), 15, ModSounds.ARMOR_EQUIP_CHAMELEON, () -> Ingredient.of(ModItemTags.CHAMELEON_SCALES),
            List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(ColdSweat.MOD_ID, "chameleon"))),
            0.0F, 0.0F));
}