package com.momosoftworks.coldsweat.api.temperature.effect.player;

import com.momosoftworks.coldsweat.api.temperature.effect.TempEffect;
import com.momosoftworks.coldsweat.api.temperature.effect.TempEffectType;
import com.momosoftworks.coldsweat.config.ConfigSettings;
import com.momosoftworks.coldsweat.core.init.ModEffects;
import com.momosoftworks.coldsweat.data.codec.util.IntegerBounds;
import com.momosoftworks.coldsweat.util.math.CSMath;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

public class FreezeMineSpeedEffect extends TempEffect
{
    public FreezeMineSpeedEffect(TempEffectType<?> type, IntegerBounds bounds)
    {   super(type, bounds);
    }

    @SubscribeEvent
    public void onPlayerMine(PlayerEvent.BreakSpeed event)
    {
        LivingEntity player = event.getEntity();
        if (!this.test(player)) return;

        float miningSpeed = 1 - ConfigSettings.COLD_MINING_IMPAIRMENT.get().floatValue();
        if (miningSpeed == 1) return;

        float effect = (float) this.getEffectFactor(player);
        float minMiningSpeed = CSMath.blend(1, miningSpeed, effect, 0, 1);
        event.setNewSpeed(event.getNewSpeed() * minMiningSpeed);
    }

    @Override
    public Side getSide()
    {   return Side.SERVER;
    }
}
